# Turbo Race — Telegram Mini App

هذه نسخة أولية تعمل كملف HTML واحد، بدون خادم وبدون Bot Token.

## التشغيل المحلي
افتح `index.html` في متصفح الهاتف أو الكمبيوتر.

## تحويلها إلى Telegram Mini App
1. ارفع `index.html` إلى استضافة HTTPS.
2. في BotFather أنشئ Web App / Menu Button واربطه برابط HTTPS.
3. لا تضع BOT_TOKEN داخل JavaScript في المتصفح.
4. بعد ذلك نضيف Backend للتحقق من Telegram WebApp initData وحفظ بيانات اللاعبين.
5. مكان الإعلان الموجود في اللعبة هو Placeholder فقط، وليس إعلان Telegram حقيقيًا.

## المراحل التالية
- ربط Telegram WebApp API.
- حسابات اللاعبين وحفظ البيانات على الخادم.
- نظام السباق الحقيقي بين لاعبين.
- لوحة المتصدرين.
- نظام الإعلانات والمكافآت وفق شروط مزود الإعلانات والقوانين المعمول بها.
